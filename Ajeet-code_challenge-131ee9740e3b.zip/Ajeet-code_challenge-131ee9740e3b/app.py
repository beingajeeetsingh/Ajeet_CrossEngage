#!flask/bin/python
from flask import Flask, jsonify, abort, make_response, request

app = Flask(__name__)

# Sample weather data for this challenge. not 
reports = [
    {
        'id': 1,
        'city': u'Berlin',
        'country': u'Germany',
        'temp': 25,
	'tempthresholdpassed': False,
        'windspeed': 45,
        'windunit': u'Imperial',
	'windspeedthresholdpassed': False
    },
    {
        'id': 2,
        'city': u'Delhi',
        'country': u'India',                                   
        'temp': 35,
        'tempthresholdpassed': False,
        'windspeed': 15,
        'windunit': u'Imperial',
        'windspeedthresholdpassed': False
    },
    {
        'id': 3,
        'city': u'Paris',
        'country': u'France',                                   
        'temp': 15,
        'tempthresholdpassed': False,
        'windspeed': 40,
        'windunit': u'Imperial',
        'windspeedthresholdpassed': False
    }
    
]

appconfig = [
    {
        'Application Name': u'Code Challenge Dummy Weather API',
	'Application Version': u'1.0.1'
    }
]

@app.route('/version', methods=['GET'])
def get_version():
    return jsonify({'Application Version': appconfig[0]['Application Version'] })

@app.route('/weather/all', methods=['GET'])
def get_tasks():
    return jsonify({'Weather Reports': reports})

@app.route('/weather', methods=['GET'])
def get_report_city():
    if 'city' in request.args:
        city = str(request.args['city'])
    else:
	return "Error: No city. Please specify a city as '?city=Berlin'"
    #Create an empty list for our results
    results = []

    for report in reports:
        if report['city'].upper() == city.upper():
	    results.append(report)
    
    return jsonify(results)

@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
