# DevOps code-challenge

#### Restfull API to get weather report  

Usage: `curl http://localhost:4000/weather?city=Muscat` and `curl http://localhost:4000/version`

(The Response comes from a dummy data, please test only  Muscat, Delhi and Paris as city parameter)

#### Pre-Requsite
* Install git
* Install Docker on target server where you want to deploy the application.  
  Installtion Details at [docs.docker.com](https://docs.docker.com/get-started/)

#### Installation and Setup

* Browse the directory on target server `cd \path\of\target_dir` 
* Clone the Repository : `git clone https://vikiscripts@bitbucket.org/vikiscripts/code_challenge.git`
* Build the container using docker : `docker build -t weather-api .`
* Run the docker container : `docker run -p 4000:80 weather-api`
* Done!!! Your Weather-api is running now
* You can test the application version using `curl http://localhost:4000/version` you will get app version as api response 

#### Design Consideration

* Docker Containers used for easy to build, test and deploy application
* Shell scripts `.\build_run_docker_container.sh` and `.\destroy_docker_container.sh` added for Building, Running and Destroying Docker containers Automatically.
* These Shell scripts can be trigerred using config managements systems to automate the build and deploy process. 
* Hosted repository for code version management
* Flask Framework used to develop the api for easy web development

#### Constraints and further improvements

* Static sample report data used, must be integrated with realtime weather api service.
* Unit testing and more error hadelling needed.

---
