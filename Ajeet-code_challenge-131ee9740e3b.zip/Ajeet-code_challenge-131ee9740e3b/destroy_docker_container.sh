#!/usr/bin/env bash

container_name="${1-flasktest}"

#Destroying Docker Container named as flasktest

container_id=$(sudo docker ps -a | grep $container_name | awk '{print $1}')

if [ -n "$container_id" ]; then
  sudo docker stop $container_id
  sudo docker rm $container_id
  if [ $? -ne 0 ]; then
      echo "Error Destroying Container"
  else
      echo "Successfully destroyed Container $container_name with id : $container_id"
  fi
else
  echo "Docker Container Not found with $container_name  name"
fi
